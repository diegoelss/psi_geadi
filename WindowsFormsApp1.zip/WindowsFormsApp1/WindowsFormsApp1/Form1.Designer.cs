﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSelecionaPasta = new System.Windows.Forms.Button();
            this.folderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.btnEnviarBD = new System.Windows.Forms.Button();
            this.txtCaminhoPasta = new System.Windows.Forms.TextBox();
            this.dgvFiles = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFiles)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSelecionaPasta
            // 
            this.btnSelecionaPasta.Location = new System.Drawing.Point(56, 83);
            this.btnSelecionaPasta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSelecionaPasta.Name = "btnSelecionaPasta";
            this.btnSelecionaPasta.Size = new System.Drawing.Size(161, 37);
            this.btnSelecionaPasta.TabIndex = 0;
            this.btnSelecionaPasta.Text = "Selecionar Pasta";
            this.btnSelecionaPasta.UseVisualStyleBackColor = true;
            this.btnSelecionaPasta.Click += new System.EventHandler(this.btnSelectFolder_Click);
            // 
            // btnEnviarBD
            // 
            this.btnEnviarBD.Location = new System.Drawing.Point(56, 153);
            this.btnEnviarBD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEnviarBD.Name = "btnEnviarBD";
            this.btnEnviarBD.Size = new System.Drawing.Size(161, 36);
            this.btnEnviarBD.TabIndex = 1;
            this.btnEnviarBD.Text = "Enviar para o BD.";
            this.btnEnviarBD.UseVisualStyleBackColor = true;
            this.btnEnviarBD.Click += new System.EventHandler(this.btnProccessFile_Click);
            // 
            // txtCaminhoPasta
            // 
            this.txtCaminhoPasta.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtCaminhoPasta.Location = new System.Drawing.Point(225, 83);
            this.txtCaminhoPasta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCaminhoPasta.Name = "txtCaminhoPasta";
            this.txtCaminhoPasta.ReadOnly = true;
            this.txtCaminhoPasta.Size = new System.Drawing.Size(496, 22);
            this.txtCaminhoPasta.TabIndex = 3;
            // 
            // dgvFiles
            // 
            this.dgvFiles.AllowUserToAddRows = false;
            this.dgvFiles.AllowUserToDeleteRows = false;
            this.dgvFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFiles.Location = new System.Drawing.Point(56, 310);
            this.dgvFiles.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvFiles.Name = "dgvFiles";
            this.dgvFiles.RowHeadersWidth = 51;
            this.dgvFiles.ShowEditingIcon = false;
            this.dgvFiles.Size = new System.Drawing.Size(800, 185);
            this.dgvFiles.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.dgvFiles);
            this.Controls.Add(this.txtCaminhoPasta);
            this.Controls.Add(this.btnEnviarBD);
            this.Controls.Add(this.btnSelecionaPasta);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "LerPasta";
            ((System.ComponentModel.ISupportInitialize)(this.dgvFiles)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSelecionaPasta;
        private System.Windows.Forms.FolderBrowserDialog folderDialog;
        private System.Windows.Forms.Button btnEnviarBD;
        private System.Windows.Forms.TextBox txtCaminhoPasta;
        private System.Windows.Forms.DataGridView dgvFiles;
    }
}

